from .softmax_xentropy import SoftmaxCrossEntropyLoss


__all__ = [
    "SoftmaxCrossEntropyLoss",
]
